
//=========================================================================================================================================================================
                                                                           //formas de cerificar se é par
// o q eu fiz
var numeros = [1,2,3,4,5]
var pares = []

if (numeros[0]% 2 == 0){
    pares.push([numeros[0]])
}
if (numeros[1]% 2 == 0){
    pares.push([numeros[1]])
}
if (numeros[2]% 2 == 0){
    pares.push([numeros[2]])
}
if (numeros[3]% 2 == 0){
    pares.push([numeros[3]])
}
if (numeros[4]% 2 == 0){
    pares.push([numeros[4]])
}
console.log(pares)


// forma-1
var lista = [1,2,3,4,5,6,7,8,9,10]
var pares = []
//length conta quantos itens tem
for (var i = 0; i < lista.length; i++){
    let resto = lista[i] % 2 
    if (resto == 0){
        pares.push(lista[i])
    }
}
console.log(pares)


//forma 2 
let minhaLista = [1, 2, 3, 4, 5];
//filter filtra os itens de acordo com uma condição, separar listas de uma lista
let novaLista = minhaLista.filter(function(elemento) {
return elemento % 2 === 0;
});
console.log(novaLista); // [2, 4]


//=====================================================================================================================================================
                                                    //verificando se os caracteres é maior que 5

//pelo filter
var string = ["hoje", "amanha", "fevereiro", "maio", "dezembro"]
var carac = string.filter(function(elemento){
    return elemento.length > 5;
});
console.log(carac);


//pelo for
var palavras = ["hoje", "amanha", "fevereiro", "maio", "dezembro"]
var caracteres = []

for(var cinco = 0; cinco < palavras.length; cinco++){
    if (palavras[cinco].length > 5){
        caracteres.push(palavras[cinco])
    }
}
console.log(caracteres)


//por if's
var strings = ["hoje", "amanha", "fevereiro", "maio", "dezembro"]
var cinco = []

if(strings[0].length > 5){
    cinco.push(strings[0])
}
if(strings[1].length > 5){
    cinco.push(strings[1])
}
if(strings[2].length > 5){
    cinco.push(strings[2])
}
if(strings[3].length > 5){
    cinco.push(strings[3])
}
if(strings[4].length > 5){
    cinco.push(strings[4])
}
console.log(cinco)

//=============================================================================================================================================================================================
                                                                   //media aritimetica

var numeros = [10,9,7,8]
var media = (numeros[0] + numeros[1] + numeros[2] + numeros[3]) / numeros.length

console.log(media)




var notas = [10,9,8,10]
var resultado = 0

for(var i = 0; i < notas.length; i++){
    resultado = notas[i] + resultado
}
var result = resultado/notas.length
console.log(result)





var notaum = Number.parseFloat (window.prompt("Digite a primeira nota"))
var notadois = Number.parseFloat (window.prompt("Digite a segunda nota"))
var notatres = Number.parseFloat (window.prompt("Digite a nota tres"))

var result =  Math.round(notaum + notadois + notatres) / 3

alert ("Sua média é:" + result)



//====================================================================================================================================================================================================
                                                                //verifica se a lista tem números pares

var numb = [2,4,8,10]
var par = []

for (var i = 0; i < numb.length; i++){
    let resto = numb[i] % 2 
    if (resto == 0){
        par.push(numb[i])
    }
}

if(numb.length == par.length){
    console.log("Tem apenas números pares")
}
